import React, { useState, useEffect } from 'react';

const App = () => {
  const [inputValue, setInputValue] = useState('');
  const [nextKeys, setNextKeys] = useState('asdfjkl;');
  const [keysPressed, setKeysPressed] = useState(0);
  const [accuracy, setAccuracy] = useState(0);
  const [timer, setTimer] = useState(300);
  const [practiceStarted, setPracticeStarted] = useState(false);

  useEffect(() => {
    let interval;
    if (practiceStarted && timer > 0) {
      interval = setInterval(() => {
        setTimer((prevTimer) => prevTimer - 1);
      }, 1000);
    } else if (timer === 0) {
      clearInterval(interval);
      setPracticeStarted(false);
    }

    return () => clearInterval(interval);
  }, [practiceStarted, timer]);

  const handleInputChange = (e) => {
    const { value } = e.target;
    setInputValue(value);
    setKeysPressed(value.length);
  };

  const calculateAccuracy = () => {
    const expectedKeys = nextKeys.slice(0, inputValue.length);
    const correctKeys = expectedKeys.split('').filter((key, index) => key === inputValue[index]);
    const accuracyPercentage = (correctKeys.length / inputValue.length) * 100;
    setAccuracy(accuracyPercentage.toFixed(2));
  };

  const startPractice = () => {
    setPracticeStarted(true);
  };

  return (
    <div>
      <h1>Touch Typing Practice</h1>
      <div>
        <div>Time Left: {timer}s</div>
        <div>Keys Pressed: {keysPressed}</div>
        <div>Accuracy: {accuracy}%</div>
      </div>
      {!practiceStarted ? (
        <button onClick={startPractice}>Start Practice</button>
      ) : (
        <div>
          <input type="text" value={inputValue} onChange={handleInputChange} />
          <div>Next Keys: {nextKeys}</div>
        </div>
      )}
    </div>
  );
};

export default App;